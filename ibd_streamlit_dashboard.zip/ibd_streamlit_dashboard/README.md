# IBD Data Inventory — Streamlit Dashboard

Production-oriented Streamlit dashboard built around the workbook tabs:

- `01_STUDIES`
- `02_DATA_AVAILABILITY`
- `03_ASSETS`
- `04_PROCESSING`
- `05_DATA_SPLITS`
- `06_ARD`
- `07_ARD_VARIABLES`
- `08_DATA_ANALYSIS`

## Run locally

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

The included workbook is loaded automatically from:

`data/vsquad_ibd_data_inventory.xlsx`

To point the app to a different workbook without changing the code:

```bash
# Windows PowerShell
$env:IBD_INVENTORY_FILE="C:\path\inventory.xlsx"
streamlit run app.py

# macOS/Linux
IBD_INVENTORY_FILE=/path/inventory.xlsx streamlit run app.py
```

## Recommended deployment pattern

For a shared environment, keep the workbook in a controlled, versioned location and expose it to the app at a stable filesystem path (or replace the loader with your approved SharePoint/S3/DB connector). Use `IBD_INVENTORY_FILE` to avoid hard-coding environment-specific paths.

## Dashboard sections

1. **Overview** — KPIs, availability matrix, disease portfolio mix, ARD/modeling status, consolidated study detail.
2. **Data Availability** — availability of videos, SDTM/ADaM, ARDs, symptoms, annotations and feature vectors.
3. **Assets** — Med.ai/data assets and technical locations.
4. **Processing** — preprocessing → feature extraction → CMES → modeling.
5. **Data Splits** — train/validation/test/holdout structure, proportions and locations.
6. **ARD & Variables** — ARD coverage and variable-level gap mapping.
7. **Analysis & Traceability** — dataset → SAP → code → analysis → results lineage.

## Data-quality behavior

Blank cells and placeholders such as `...` are treated as unknown rather than automatically classified as missing. This avoids creating false certainty from incomplete inventory fields.
