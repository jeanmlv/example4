"""IBD Streamlit dashboard package."""
