# ARGES Commons Dashboard

Modular Streamlit dashboard for the ARGES Commons clinical data inventory.

## Run
```bash
pip install -r requirements.txt
streamlit run app.py
```

Place `ARGES_COMMONS.xlsx` in the project root beside `app.py`.
