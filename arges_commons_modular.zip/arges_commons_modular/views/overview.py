import pandas as pd
import plotly.express as px
import streamlit as st
from src.config import JNJ_RED

def render(filtered,data):
    s=filtered['01_STUDIES']; avail=filtered.get('02_DATA_AVAILABILITY',pd.DataFrame()); ard=filtered.get('06_ARD',pd.DataFrame())
    c1,c2,c3,c4,c5=st.columns(5)
    c1.metric('Studies',s['Study ID'].nunique() if 'Study ID' in s else 0)
    c2.metric('Patients',f"{pd.to_numeric(s.get('Patients'),errors='coerce').sum():,.0f}" if 'Patients' in s else '—')
    c3.metric('Videos',f"{pd.to_numeric(s.get('Videos'),errors='coerce').sum():,.0f}" if 'Videos' in s else '—')
    aa=avail['Analysis-Ready-Dataset (ARD)'].astype(str).str.lower().eq('available').sum() if 'Analysis-Ready-Dataset (ARD)' in avail else 0
    c4.metric('ARD available',aa); avg=pd.to_numeric(ard.get('Coverage %'),errors='coerce').mean() if 'Coverage %' in ard else float('nan'); c5.metric('Mean ARD coverage',f'{avg:.0%}' if pd.notna(avg) else '—')
    left,right=st.columns([1,1],gap='large')
    with left:
        st.markdown('### Portfolio by disease')
        if 'Disease' in s and not s.empty:
            x=s['Disease'].fillna('Not specified').value_counts().reset_index(); x.columns=['Disease','Studies']; fig=px.bar(x,x='Studies',y='Disease',orientation='h',text='Studies',color_discrete_sequence=[JNJ_RED]); fig.update_layout(height=330,margin=dict(l=5,r=10,t=15,b=10),yaxis_title='',xaxis_title='Studies',showlegend=False); st.plotly_chart(fig,use_container_width=True)
    with right:
        st.markdown('### Trial status')
        if 'Trial Status' in s and not s['Trial Status'].dropna().empty:
            x=s['Trial Status'].fillna('Not specified').astype(str).value_counts().reset_index(); x.columns=['Trial Status','Count']; fig=px.pie(x,names='Trial Status',values='Count',hole=.62,color_discrete_sequence=[JNJ_RED,'#F97066','#FECACA','#667085','#98A2B3']); fig.update_traces(textposition='inside',textinfo='percent'); fig.update_layout(height=330,margin=dict(l=5,r=10,t=15,b=10),legend=dict(orientation='v',yanchor='middle',y=.5,xanchor='left',x=1.02),legend_title_text=''); st.plotly_chart(fig,use_container_width=True)
