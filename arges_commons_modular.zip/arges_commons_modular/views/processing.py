import pandas as pd
import plotly.express as px
import streamlit as st
from src.ui import show_table,download_row

def render(filtered,data):
    st.header('Processing'); st.markdown('<div class="section-note">Pipeline readiness from preprocessing and feature extraction through CMES inference and modeling.</div>',unsafe_allow_html=True); df=filtered.get('04_PROCESSING',pd.DataFrame()); stages=[c for c in ['Preprocessing','Feature Extraction','CMES Inference','Modeling'] if c in df.columns]
    if stages and not df.empty:
        long=df.melt(id_vars=[c for c in ['Study ID','Study Name'] if c in df],value_vars=stages,var_name='Stage',value_name='Status'); long['Status']=long['Status'].fillna('Not specified'); x=long.groupby(['Stage','Status'],as_index=False).size().rename(columns={'size':'Studies'}); fig=px.bar(x,x='Stage',y='Studies',color='Status',barmode='stack',color_discrete_map={'Complete':'#12B76A','Pending':'#F79009','Not Started':'#D92D20','Not specified':'#D0D5DD'}); fig.update_layout(height=360,margin=dict(l=5,r=5,t=15,b=10),legend_title_text=''); st.plotly_chart(fig,use_container_width=True)
    show_table(df,key='processing_table'); download_row(df,'filtered_processing')
