import pandas as pd
import streamlit as st
from src.filters import clean_text_values
from src.ui import show_table,download_row

def render(filtered,data):
    st.header('Variable Definitions & Traceability'); st.markdown('<div class="section-note">Search variables of interest and trace their mapping into ARD variables across UC and CD studies.</div>',unsafe_allow_html=True); m=filtered.get('06C_ARD_VARIABLES',pd.DataFrame()); cd=data.get('06A_CD_VOI',pd.DataFrame()).copy(); uc=data.get('06B_UC_VOI',pd.DataFrame()).copy(); q=st.text_input('Search variable',placeholder='e.g., CALPRO, MAYO, RHI, endoscopy...'); statuses=st.multiselect('Mapping status',clean_text_values(m.get('Status',pd.Series(dtype=str)))); view=m.copy()
    if q:
        searchable=[c for c in ['Variable of Interest','Description','ARD Variable','ARD Description'] if c in view]; mask=pd.Series(False,index=view.index)
        for c in searchable: mask|=view[c].fillna('').astype(str).str.contains(q,case=False,regex=False)
        view=view[mask]
    if statuses and 'Status' in view: view=view[view['Status'].astype(str).isin(statuses)]
    c1,c2,c3,c4=st.columns(4); c1.metric('Mapping rows',len(view)); c2.metric('VOI',view['Variable of Interest'].nunique() if 'Variable of Interest' in view else 0); c3.metric('Mapped',view['Status'].astype(str).str.lower().eq('mapped').sum() if 'Status' in view else 0); c4.metric('Studies',view['Study Name'].nunique() if 'Study Name' in view else 0); t1,t2,t3=st.tabs(['ARD variable mapping','CD variables of interest','UC variables of interest'])
    with t1: show_table(view,key='variable_mapping_table',max_rows=18); download_row(view,'filtered_ard_variables')
    with t2: show_table(cd,key='cd_voi_table',max_rows=18)
    with t3: show_table(uc,key='uc_voi_table',max_rows=18)
