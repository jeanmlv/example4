from pathlib import Path
import re
import pandas as pd
import streamlit as st

@st.cache_data(show_spinner=False)
def load_workbook(source) -> dict[str, pd.DataFrame]:
    sheets = pd.read_excel(source, sheet_name=None, engine='openpyxl')
    out = {}
    for name, df in sheets.items():
        df = df.copy()
        df.columns = [re.sub(r'\s+', ' ', str(c).replace('\n',' ')).strip() for c in df.columns]
        out[name] = df.dropna(how='all')
    return out

def resolve_default_workbook() -> Path | None:
    root = Path(__file__).resolve().parent.parent
    preferred = root / 'ARGES_COMMONS.xlsx'
    if preferred.exists(): return preferred
    candidates = sorted(root.glob('ARGES_COMMONS*.xlsx'))
    return candidates[0] if candidates else None

def filter_by_study(df: pd.DataFrame, study_ids: set[str]) -> pd.DataFrame:
    if df.empty or 'Study ID' not in df.columns or not study_ids:
        return df.iloc[0:0].copy() if not study_ids and 'Study ID' in df.columns else df.copy()
    return df[df['Study ID'].astype(str).isin(study_ids)].copy()
